# BLE File Transfer Protocol - Updated Implementation

## Overview

The SalesTag ESP32-S3 device now implements a streaming file transfer protocol where the ESP32 acts as a **file sender**. The mobile app requests files from the ESP32, which reads them from the SD card and streams them to the mobile app via BLE notifications.

## Protocol Specification

### Service UUIDs
- **File Transfer Service**: `0x1240`
- **File Control Characteristic**: `0x1241`
- **File Data Characteristic**: `0x1242`
- **File Status Characteristic**: `0x1243`

### File Control Commands (1 byte each)
- `0x01` - START: Begin file transfer
- `0x02` - PAUSE: Pause transfer
- `0x03` - RESUME: Resume transfer
- `0x04` - STOP: Stop transfer

### File Data Packet Format
Each notification contains:
- **Header (5 bytes)**:
  - `seq`: uint16 LE (sequence number)
  - `len`: uint16 LE (payload length)
  - `flags`: uint8 (bit0 = EOF flag)
- **Payload**: `len` bytes of file data

### File Status Notifications (8 bytes)
- `status_code`: uint32 LE (status code)
- `bytes_sent`: uint32 LE (total bytes sent)

### Status Codes
- `0x00000000` - STAT_STARTED
- `0x00000001` - STAT_COMPLETE
- `0x00000002` - STAT_STOPPED_BY_HOST
- `0x00000010` - STAT_FILE_OPEN_FAIL
- `0x00000011` - STAT_NOTIFY_FAIL
- `0x00000020` - STAT_BAD_CMD
- `0x00000021` - STAT_ALREADY_RUNNING
- `0x00000030` - STAT_PAUSED

## Usage Flow

1. **Connect** to ESP32 device
2. **Request MTU** 185 for optimal performance
3. **Write 0x01** to File Control characteristic (with response)
4. **Receive** STAT_STARTED notification
5. **Receive** File Data notifications with 5-byte headers
6. **Receive** STAT_COMPLETE when transfer finishes

## Implementation Details

### MTU Handling
- Device requests MTU 185 on connection
- Payload size = min(negotiated_mtu - 3, 180)
- Hard cap of 180 bytes per payload

### Congestion Control
- Device respects BLE congestion events
- Automatically resumes when congestion clears
- No data loss during congestion

### Error Handling
- Invalid command lengths return ATT invalid attribute value length
- Missing files return STAT_FILE_OPEN_FAIL
- All errors return appropriate status codes

### File Operations
- Files opened read-only from SD card
- No file creation or writing in file service
- Default file: `/sdcard/ble_transfer.dat`

## Mobile App Integration

### iOS (Swift)
```swift
// Write START command
let startCommand = Data([0x01])
try await peripheral.writeValue(startCommand, for: fileControlCharacteristic, type: .withResponse)

// Enable notifications
peripheral.setNotifyValue(true, for: fileDataCharacteristic)
peripheral.setNotifyValue(true, for: fileStatusCharacteristic)
```

### Android (Kotlin)
```kotlin
// Write START command
val startCommand = byteArrayOf(0x01)
gatt.writeCharacteristic(fileControlChar.apply { value = startCommand })

// Enable notifications
gatt.setCharacteristicNotification(fileDataChar, true)
gatt.setCharacteristicNotification(fileStatusChar, true)
```

## Testing

### Test File
A 64KB test file is provided at `/sdcard/ble_transfer.dat` with known content for validation.

### Expected Log Output
```
[MTU] requested=185 negotiated=185
[CTRL] cmd=START file=/sdcard/ble_transfer.dat size=65536
[STATUS] code=STAT_STARTED bytes=0
[DATA] seq=0 len=180 eof=0 total=180
[DATA] seq=363 len=176 eof=1 total=65536
[STATUS] code=STAT_COMPLETE bytes=65536
```

## Compliance Checklist

- ✅ 1-byte FILE_CTRL writes enforced
- ✅ FILE_DATA notify-only
- ✅ Proper packet headers (5 bytes)
- ✅ Status notifications (8 bytes)
- ✅ MTU-based payload sizing
- ✅ Congestion handling
- ✅ All required status codes
- ✅ No receive mode remaining
