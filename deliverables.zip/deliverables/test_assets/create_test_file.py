#!/usr/bin/env python3
"""
Create a 64KB test file for BLE file transfer testing
This script creates a test file with known content for validation
"""

import struct
import hashlib

def create_test_file(filename, size=65536):
    """Create a test file with known content"""
    
    print(f"Creating test file: {filename}")
    print(f"File size: {size} bytes ({size/1024:.1f} KB)")
    
    with open(filename, 'wb') as f:
        # Write a header
        f.write(b'BLE_TRANSFER_TEST_FILE\n')
        f.write(struct.pack('<I', size))  # File size as little-endian uint32
        
        # Fill the rest with a repeating pattern
        pattern = b'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789'
        remaining = size - 30  # Subtract header size
        
        while remaining > 0:
            chunk_size = min(len(pattern), remaining)
            f.write(pattern[:chunk_size])
            remaining -= chunk_size
    
    # Calculate SHA256 hash
    with open(filename, 'rb') as f:
        file_hash = hashlib.sha256(f.read()).hexdigest()
    
    print(f"Test file created: {filename}")
    print(f"File size: {size} bytes")
    print(f"SHA256: {file_hash}")
    print("Pattern: ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789")
    
    # Save hash to file
    hash_filename = filename + '.sha256'
    with open(hash_filename, 'w') as f:
        f.write(f"{file_hash}  {filename}\n")
    
    print(f"Hash saved to: {hash_filename}")
    
    return file_hash

if __name__ == "__main__":
    # Create the test file
    test_file = "ble_transfer.dat"
    hash_value = create_test_file(test_file, 65536)
    
    print("\nTest file ready for BLE transfer testing!")
    print("Place this file on the ESP32's SD card at /sdcard/ble_transfer.dat")
