import CoreBluetooth
import Foundation

class FileTransferClient: NSObject, CBCentralManagerDelegate, CBPeripheralDelegate {
    
    // Service and characteristic UUIDs
    private let fileServiceUUID = CBUUID(string: "1240")
    private let fileControlUUID = CBUUID(string: "1241")
    private let fileDataUUID = CBUUID(string: "1242")
    private let fileStatusUUID = CBUUID(string: "1243")
    
    // BLE components
    private var centralManager: CBCentralManager!
    private var peripheral: CBPeripheral?
    private var fileControlCharacteristic: CBCharacteristic?
    private var fileDataCharacteristic: CBCharacteristic?
    private var fileStatusCharacteristic: CBCharacteristic?
    
    // File transfer state
    private var isTransferring = false
    private var receivedData = Data()
    private var expectedFileSize: UInt32 = 0
    private var bytesReceived: UInt32 = 0
    
    // Callbacks
    var onTransferComplete: ((Data) -> Void)?
    var onTransferError: ((String) -> Void)?
    var onStatusUpdate: ((String) -> Void)?
    
    override init() {
        super.init()
        centralManager = CBCentralManager(delegate: self, queue: nil)
    }
    
    // MARK: - BLE Management
    
    func startScanning() {
        guard centralManager.state == .poweredOn else {
            onTransferError?("Bluetooth not available")
            return
        }
        
        centralManager.scanForPeripherals(withServices: [fileServiceUUID], options: nil)
        onStatusUpdate?("Scanning for ESP32 device...")
    }
    
    func stopScanning() {
        centralManager.stopScan()
    }
    
    // MARK: - CBCentralManagerDelegate
    
    func centralManagerDidUpdateState(_ central: CBCentralManager) {
        switch central.state {
        case .poweredOn:
            onStatusUpdate?("Bluetooth ready")
        case .poweredOff:
            onTransferError?("Bluetooth powered off")
        case .unauthorized:
            onTransferError?("Bluetooth unauthorized")
        default:
            onTransferError?("Bluetooth not available")
        }
    }
    
    func centralManager(_ central: CBCentralManager, didDiscover peripheral: CBPeripheral, advertisementData: [String : Any], rssi RSSI: NSNumber) {
        if peripheral.name == "ESP32-S3-Mini-BLE" {
            self.peripheral = peripheral
            peripheral.delegate = self
            central.connect(peripheral, options: nil)
            central.stopScan()
            onStatusUpdate?("Connecting to ESP32...")
        }
    }
    
    func centralManager(_ central: CBCentralManager, didConnect peripheral: CBPeripheral) {
        onStatusUpdate?("Connected to ESP32")
        peripheral.discoverServices([fileServiceUUID])
    }
    
    func centralManager(_ central: CBCentralManager, didDisconnectPeripheral peripheral: CBPeripheral, error: Error?) {
        onStatusUpdate?("Disconnected from ESP32")
        if let error = error {
            onTransferError?("Disconnection error: \(error.localizedDescription)")
        }
    }
    
    // MARK: - CBPeripheralDelegate
    
    func peripheral(_ peripheral: CBPeripheral, didDiscoverServices error: Error?) {
        guard error == nil else {
            onTransferError?("Service discovery error: \(error!.localizedDescription)")
            return
        }
        
        guard let services = peripheral.services else { return }
        
        for service in services {
            if service.uuid == fileServiceUUID {
                peripheral.discoverCharacteristics([fileControlUUID, fileDataUUID, fileStatusUUID], for: service)
                break
            }
        }
    }
    
    func peripheral(_ peripheral: CBPeripheral, didDiscoverCharacteristicsFor service: CBService, error: Error?) {
        guard error == nil else {
            onTransferError?("Characteristic discovery error: \(error!.localizedDescription)")
            return
        }
        
        guard let characteristics = service.characteristics else { return }
        
        for characteristic in characteristics {
            switch characteristic.uuid {
            case fileControlUUID:
                fileControlCharacteristic = characteristic
            case fileDataUUID:
                fileDataCharacteristic = characteristic
                peripheral.setNotifyValue(true, for: characteristic)
            case fileStatusUUID:
                fileStatusCharacteristic = characteristic
                peripheral.setNotifyValue(true, for: characteristic)
            default:
                break
            }
        }
        
        onStatusUpdate?("Ready for file transfer")
    }
    
    func peripheral(_ peripheral: CBPeripheral, didUpdateValueFor characteristic: CBCharacteristic, error: Error?) {
        guard error == nil else {
            onTransferError?("Characteristic update error: \(error!.localizedDescription)")
            return
        }
        
        guard let data = characteristic.value else { return }
        
        switch characteristic.uuid {
        case fileDataUUID:
            handleFileData(data)
        case fileStatusUUID:
            handleStatusUpdate(data)
        default:
            break
        }
    }
    
    // MARK: - File Transfer
    
    func startFileTransfer() {
        guard let characteristic = fileControlCharacteristic else {
            onTransferError?("File control characteristic not found")
            return
        }
        
        let startCommand = Data([0x01])
        peripheral?.writeValue(startCommand, for: characteristic, type: .withResponse)
        onStatusUpdate?("Starting file transfer...")
    }
    
    func pauseFileTransfer() {
        guard let characteristic = fileControlCharacteristic else { return }
        let pauseCommand = Data([0x02])
        peripheral?.writeValue(pauseCommand, for: characteristic, type: .withResponse)
        onStatusUpdate?("Pausing file transfer...")
    }
    
    func resumeFileTransfer() {
        guard let characteristic = fileControlCharacteristic else { return }
        let resumeCommand = Data([0x03])
        peripheral?.writeValue(resumeCommand, for: characteristic, type: .withResponse)
        onStatusUpdate?("Resuming file transfer...")
    }
    
    func stopFileTransfer() {
        guard let characteristic = fileControlCharacteristic else { return }
        let stopCommand = Data([0x04])
        peripheral?.writeValue(stopCommand, for: characteristic, type: .withResponse)
        onStatusUpdate?("Stopping file transfer...")
    }
    
    // MARK: - Data Handling
    
    private func handleFileData(_ data: Data) {
        guard data.count >= 5 else {
            onTransferError?("Invalid file data packet (too short)")
            return
        }
        
        // Parse header (5 bytes)
        let seq = data.prefix(2).withUnsafeBytes { $0.load(as: UInt16.self).littleEndian }
        let len = data.dropFirst(2).prefix(2).withUnsafeBytes { $0.load(as: UInt16.self).littleEndian }
        let flags = data[4]
        let payload = data.dropFirst(5)
        
        // Validate payload length
        guard payload.count == len else {
            onTransferError?("Payload length mismatch: expected \(len), got \(payload.count)")
            return
        }
        
        // Add payload to received data
        receivedData.append(payload)
        bytesReceived += UInt32(len)
        
        onStatusUpdate?("Received chunk \(seq): \(len) bytes, total: \(bytesReceived)")
        
        // Check for EOF
        if (flags & 0x01) != 0 {
            onStatusUpdate?("File transfer complete: \(bytesReceived) bytes")
            onTransferComplete?(receivedData)
            receivedData.removeAll()
            bytesReceived = 0
        }
    }
    
    private func handleStatusUpdate(_ data: Data) {
        guard data.count == 8 else {
            onTransferError?("Invalid status packet (wrong size)")
            return
        }
        
        let statusCode = data.prefix(4).withUnsafeBytes { $0.load(as: UInt32.self).littleEndian }
        let bytesSent = data.dropFirst(4).withUnsafeBytes { $0.load(as: UInt32.self).littleEndian }
        
        switch statusCode {
        case 0x00000000:
            onStatusUpdate?("Transfer started")
        case 0x00000001:
            onStatusUpdate?("Transfer completed: \(bytesSent) bytes sent")
        case 0x00000002:
            onStatusUpdate?("Transfer stopped by host")
        case 0x00000010:
            onTransferError?("File open failed")
        case 0x00000011:
            onTransferError?("Notification failed")
        case 0x00000020:
            onTransferError?("Bad command")
        case 0x00000021:
            onTransferError?("Transfer already running")
        case 0x00000030:
            onStatusUpdate?("Transfer paused")
        default:
            onStatusUpdate?("Unknown status: 0x\(String(format: "%08x", statusCode))")
        }
    }
}

// MARK: - Usage Example

/*
let client = FileTransferClient()

client.onTransferComplete = { data in
    print("File received: \(data.count) bytes")
    // Save or process the file data
}

client.onTransferError = { error in
    print("Transfer error: \(error)")
}

client.onStatusUpdate = { status in
    print("Status: \(status)")
}

// Start the transfer
client.startScanning()

// Once connected and ready:
client.startFileTransfer()
*/
