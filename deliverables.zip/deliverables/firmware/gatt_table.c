// GATT Service Definition for File Transfer Service
// This shows the FILE_CTRL characteristic with exactly 1 byte length enforcement

static const struct ble_gatt_svc_def gatt_svr_svcs[] = {
    {
        .type = BLE_GATT_SVC_TYPE_PRIMARY,
        .uuid = BLE_UUID16_DECLARE(BLE_UUID_SALESTAG_FILE_SVC),
        .characteristics = (struct ble_gatt_chr_def[]) { 
            {
                .uuid = BLE_UUID16_DECLARE(BLE_UUID_SALESTAG_FILE_CTRL),
                .access_cb = gatt_svr_chr_access,
                .flags = BLE_GATT_CHR_F_WRITE | BLE_GATT_CHR_F_WRITE_NO_RSP,
                .val_handle = NULL,
            }, 
            {
                .uuid = BLE_UUID16_DECLARE(BLE_UUID_SALESTAG_FILE_DATA),
                .access_cb = gatt_svr_chr_access,
                .flags = BLE_GATT_CHR_F_NOTIFY,
                .val_handle = NULL,
            }, 
            {
                .uuid = BLE_UUID16_DECLARE(BLE_UUID_SALESTAG_FILE_STATUS),
                .access_cb = gatt_svr_chr_access,
                .flags = BLE_GATT_CHR_F_NOTIFY,
                .val_handle = NULL,
            }, 
            {
                0, /* No more characteristics in this service */
            } 
        },
    },
    {
        0, /* No more services */
    },
};

// GATT Access Control for FILE_CTRL - enforces exactly 1 byte writes
static int gatt_svr_chr_access(uint16_t conn_handle, uint16_t attr_handle,
                              struct ble_gatt_access_ctxt *ctxt, void *arg)
{
    const struct ble_gatt_chr_def *chr_def;
    uint16_t uuid16;
    int rc;
    
    chr_def = ctxt->chr;
    uuid16 = ble_uuid_u16(chr_def->uuid);
    
    switch (uuid16) {
    case BLE_UUID_SALESTAG_FILE_CTRL:
        if (ctxt->op == BLE_GATT_ACCESS_OP_WRITE_CHR) {
            // Handle file transfer control commands - exactly 1 byte required
            if (ctxt->om->om_len != 1) {
                ESP_LOGW(TAG, "Invalid file control write length: %d (expected 1)", ctxt->om->om_len);
                return BLE_ATT_ERR_INVALID_ATTR_VALUE_LEN;
            }
            
            uint8_t cmd;
            rc = ble_hs_mbuf_to_flat(ctxt->om, &cmd, sizeof(cmd), NULL);
            if (rc != 0) {
                return BLE_ATT_ERR_UNLIKELY;
            }
            
            ESP_LOGI(TAG, "File control write: cmd=0x%02x", cmd);
            
            switch (cmd) {
            case FILE_TRANSFER_CMD_START:
                return file_transfer_start();
                
            case FILE_TRANSFER_CMD_PAUSE:
                return file_transfer_pause();
                
            case FILE_TRANSFER_CMD_RESUME:
                return file_transfer_resume();
                
            case FILE_TRANSFER_CMD_STOP:
                return file_transfer_stop();
                
            default:
                ESP_LOGW(TAG, "Unknown file transfer command: 0x%02x", cmd);
                send_status(STAT_BAD_CMD);
                return BLE_ATT_ERR_INVALID_ATTR_VALUE_LEN;
            }
        }
        break;
        
    case BLE_UUID_SALESTAG_FILE_DATA:
        // File data characteristic is notify-only, no writes allowed
        if (ctxt->op == BLE_GATT_ACCESS_OP_WRITE_CHR) {
            ESP_LOGW(TAG, "File data characteristic is notify-only, writes not allowed");
            return BLE_ATT_ERR_WRITE_NOT_PERMITTED;
        }
        break;
        
    case BLE_UUID_SALESTAG_FILE_STATUS:
        // File status characteristic is notify-only, no reads allowed
        if (ctxt->op == BLE_GATT_ACCESS_OP_READ_CHR) {
            ESP_LOGW(TAG, "File status characteristic is notify-only, reads not allowed");
            return BLE_ATT_ERR_READ_NOT_PERMITTED;
        }
        break;
    }
    
    return BLE_ATT_ERR_UNLIKELY;
}
