// File Transfer Service Implementation - Streaming Logic
// ESP32 reads files from SD card and streams them to mobile app via notifications

#include "protocol.h"
#include "esp_log.h"
#include <stdio.h>
#include <string.h>

static const char *TAG = "file_service";

// Global state for file transfer
static uint16_t s_file_transfer_conn_handle = BLE_HS_CONN_HANDLE_NONE;
static uint16_t s_file_transfer_status_handle = 0;
static uint16_t s_file_transfer_data_handle = 0;
static bool s_file_transfer_active = false;
static bool s_file_transfer_paused = false;
static uint32_t s_file_transfer_size = 0;
static uint32_t s_file_transfer_offset = 0;
static uint32_t s_bytes_sent = 0;
static uint16_t s_seq = 0;
static char s_file_transfer_filename[128] = {0};
static FILE* s_file_transfer_fp = NULL;

// MTU and payload handling
static uint16_t s_mtu = 23;
static size_t s_payload_max = 20; // mtu - 3

// File transfer helper functions
static void file_transfer_notify_status(uint32_t status_code, uint32_t bytes_sent);
static int file_transfer_start(void);
static int file_transfer_stop(void);
static int file_transfer_pause(void);
static int file_transfer_resume(void);
static void pump_file_chunks(void);
static void send_status(uint32_t code);
static void stop_streaming(uint32_t code);
static void update_payload_len(uint16_t mtu);

// MTU update function
static void update_payload_len(uint16_t mtu)
{
    s_mtu = mtu;
    s_payload_max = (mtu > 23) ? (mtu - 3) : 20;
    if (s_payload_max > FILE_TRANSFER_MAX_PAYLOAD) {
        s_payload_max = FILE_TRANSFER_MAX_PAYLOAD;
    }
    
    ESP_LOGI(TAG, "[MTU] requested=185 negotiated=%d payload_max=%d", s_mtu, s_payload_max);
}

// Start file transfer - ESP32 opens file for reading
static int file_transfer_start(void)
{
    if (s_file_transfer_active) {
        ESP_LOGW(TAG, "File transfer already active");
        send_status(STAT_ALREADY_RUNNING);
        return BLE_ATT_ERR_INVALID_ATTR_VALUE_LEN;
    }
    
    // Check if SD card is available
    if (!sd_storage_is_available()) {
        ESP_LOGE(TAG, "SD card not available for file transfer");
        send_status(STAT_FILE_OPEN_FAIL);
        return BLE_ATT_ERR_INVALID_ATTR_VALUE_LEN;
    }
    
    // Open file for reading (ESP32 acts as file sender)
    snprintf(s_file_transfer_filename, sizeof(s_file_transfer_filename), FILE_TRANSFER_DEFAULT_FILENAME);
    
    s_file_transfer_fp = fopen(s_file_transfer_filename, "rb");
    if (!s_file_transfer_fp) {
        ESP_LOGE(TAG, "Failed to open file for reading: %s (errno: %d)", s_file_transfer_filename, errno);
        send_status(STAT_FILE_OPEN_FAIL);
        return BLE_ATT_ERR_INVALID_ATTR_VALUE_LEN;
    }
    
    // Get file size
    fseek(s_file_transfer_fp, 0, SEEK_END);
    s_file_transfer_size = ftell(s_file_transfer_fp);
    fseek(s_file_transfer_fp, 0, SEEK_SET);
    
    s_file_transfer_active = true;
    s_file_transfer_paused = false;
    s_file_transfer_offset = 0;
    s_bytes_sent = 0;
    s_seq = 0;
    
    ESP_LOGI(TAG, "[CTRL] cmd=START file=%s size=%lu", s_file_transfer_filename, s_file_transfer_size);
    send_status(STAT_STARTED);
    
    // Start pumping file chunks
    pump_file_chunks();
    
    return 0;
}

// Stop file transfer
static int file_transfer_stop(void)
{
    if (!s_file_transfer_active) {
        ESP_LOGW(TAG, "No active file transfer to stop");
        return BLE_ATT_ERR_INVALID_ATTR_VALUE_LEN;
    }
    
    ESP_LOGI(TAG, "[CTRL] cmd=STOP");
    stop_streaming(STAT_STOPPED_BY_HOST);
    
    return 0;
}

// Pause file transfer
static int file_transfer_pause(void)
{
    if (!s_file_transfer_active) {
        ESP_LOGW(TAG, "No active file transfer to pause");
        return BLE_ATT_ERR_INVALID_ATTR_VALUE_LEN;
    }
    
    s_file_transfer_paused = true;
    ESP_LOGI(TAG, "[CTRL] cmd=PAUSE");
    send_status(STAT_PAUSED);
    
    return 0;
}

// Resume file transfer
static int file_transfer_resume(void)
{
    if (!s_file_transfer_active) {
        ESP_LOGW(TAG, "No active file transfer to resume");
        return BLE_ATT_ERR_INVALID_ATTR_VALUE_LEN;
    }
    
    if (!s_file_transfer_fp) {
        ESP_LOGE(TAG, "File not open for resume");
        send_status(STAT_FILE_OPEN_FAIL);
        return BLE_ATT_ERR_INVALID_ATTR_VALUE_LEN;
    }
    
    s_file_transfer_paused = false;
    ESP_LOGI(TAG, "[CTRL] cmd=RESUME");
    
    // Continue pumping file chunks
    pump_file_chunks();
    
    return 0;
}

// Pump file chunks with proper packet formatting
static void pump_file_chunks(void)
{
    if (!s_file_transfer_active || !s_file_transfer_fp || s_file_transfer_paused) {
        return;
    }
    
    uint8_t pkt[200]; // Max packet size including header
    const size_t hdr_size = sizeof(file_transfer_header_t);
    
    while (s_file_transfer_active && !s_file_transfer_paused) {
        // Calculate how much data to read based on MTU
        size_t to_read = s_payload_max;
        if (to_read > sizeof(pkt) - hdr_size) {
            to_read = sizeof(pkt) - hdr_size;
        }
        
        // Read data from file
        size_t n = fread(pkt + hdr_size, 1, to_read, s_file_transfer_fp);
        bool eof = (n < to_read);
        
        // Prepare packet header
        file_transfer_header_t *header = (file_transfer_header_t *)pkt;
        header->seq = s_seq;
        header->len = n;
        header->flags = eof ? 0x01 : 0x00;
        
        // Send notification
        int rc = ble_gatts_chr_updated_ind(s_file_transfer_conn_handle, 
                                          s_file_transfer_data_handle,
                                          hdr_size + n, pkt);
        
        if (rc == 0) {
            s_bytes_sent += n;
            s_seq++;
            ESP_LOGD(TAG, "[DATA] seq=%d len=%d eof=%d total=%lu", 
                     s_seq-1, n, header->flags, s_bytes_sent);
            
            if (eof) {
                ESP_LOGI(TAG, "File transfer complete: %lu bytes sent", s_bytes_sent);
                stop_streaming(STAT_COMPLETE);
                break;
            }
        } else if (rc == BLE_HS_ECONTROLLER) {
            // Congestion - stop pumping, will resume when congestion clears
            ESP_LOGD(TAG, "BLE congestion detected, stopping pump");
            break;
        } else {
            ESP_LOGE(TAG, "Failed to send file data: %d", rc);
            stop_streaming(STAT_NOTIFY_FAIL);
            break;
        }
    }
}

// Send status notification
static void send_status(uint32_t code)
{
    if (s_file_transfer_conn_handle == BLE_HS_CONN_HANDLE_NONE || 
        s_file_transfer_status_handle == 0) {
        return;
    }
    
    file_transfer_status_t status = {
        .status_code = code,
        .bytes_sent = s_bytes_sent
    };
    
    int rc = ble_gatts_chr_updated_ind(s_file_transfer_conn_handle, 
                                      s_file_transfer_status_handle,
                                      sizeof(status), (uint8_t*)&status);
    
    if (rc == 0) {
        ESP_LOGI(TAG, "[STATUS] code=0x%08x bytes=%lu", code, s_bytes_sent);
    } else {
        ESP_LOGE(TAG, "Failed to send status: %d", rc);
    }
}

// Stop streaming and clean up
static void stop_streaming(uint32_t code)
{
    if (s_file_transfer_fp) {
        fclose(s_file_transfer_fp);
        s_file_transfer_fp = NULL;
    }
    
    s_file_transfer_active = false;
    s_file_transfer_paused = false;
    
    send_status(code);
}

// Handle congestion events
void file_transfer_handle_congestion(bool congested)
{
    if (!congested && s_file_transfer_active && !s_file_transfer_paused) {
        ESP_LOGI(TAG, "BLE congestion cleared, resuming file transfer");
        pump_file_chunks();
    }
}
