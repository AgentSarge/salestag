#ifndef BLE_FILE_TRANSFER_PROTOCOL_H
#define BLE_FILE_TRANSFER_PROTOCOL_H

#include <stdint.h>

// Service UUIDs
#define BLE_UUID_SALESTAG_FILE_SVC     0x1240
#define BLE_UUID_SALESTAG_FILE_CTRL    0x1241
#define BLE_UUID_SALESTAG_FILE_DATA    0x1242
#define BLE_UUID_SALESTAG_FILE_STATUS  0x1243

// File transfer command definitions
#define FILE_TRANSFER_CMD_START        0x01
#define FILE_TRANSFER_CMD_PAUSE        0x02
#define FILE_TRANSFER_CMD_RESUME       0x03
#define FILE_TRANSFER_CMD_STOP         0x04

// File transfer status codes
#define STAT_STARTED                   0x00000000
#define STAT_COMPLETE                  0x00000001
#define STAT_STOPPED_BY_HOST           0x00000002
#define STAT_FILE_OPEN_FAIL            0x00000010
#define STAT_NOTIFY_FAIL               0x00000011
#define STAT_BAD_CMD                   0x00000020
#define STAT_ALREADY_RUNNING           0x00000021
#define STAT_PAUSED                    0x00000030

// File transfer packet header (5 bytes)
typedef struct {
    uint16_t seq;      // Sequence number (little endian)
    uint16_t len;      // Payload length (little endian)
    uint8_t flags;     // Flags (bit0 = EOF)
} __attribute__((packed)) file_transfer_header_t;

// File transfer status notification (8 bytes)
typedef struct {
    uint32_t status_code;  // Status code (little endian)
    uint32_t bytes_sent;   // Bytes sent (little endian)
} __attribute__((packed)) file_transfer_status_t;

// Protocol constants
#define FILE_TRANSFER_MAX_PAYLOAD      180
#define FILE_TRANSFER_DEFAULT_MTU      185
#define FILE_TRANSFER_DEFAULT_FILENAME "/sdcard/ble_transfer.dat"

#endif // BLE_FILE_TRANSFER_PROTOCOL_H
